#!/usr/bin/env bash

BWHITE=$'\e[1;37m'
BLACK=$'\e[0;30m'
BBLACK=$'\e[1;30m'
YELLOWBG=$'\e[43m'

BRED=$'\e[1;31m'
BBLUE=$'\e[1;34m'
BLUE=$'\e[0;34m'
BCYAN=$'\e[1;36m'
CYAN=$'\e[0;36m'
BHBLUE=$'\e[1;94m'
HBLUE=$'\e[0;94m'
BYELLOW=$'\e[1;33m'
YELLOW=$'\e[0;33m'
GREEN=$'\e[0;32m'
BGREEN=$'\e[1;32m'
NC=$'\e[0m'

ULINEYELLOW=$'\e[4;33m'
ULINEWHITE=$'\e[4;37m'
ULINEGREEN=$'\e[4;32m'
ULINERED=$'\e[4;31m'